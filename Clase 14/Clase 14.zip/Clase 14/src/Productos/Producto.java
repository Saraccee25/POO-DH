package Productos;

public abstract class Producto {
    //atributos
    private double peso;

    //metodos
    public abstract double calcularEspacio();

}
